export type SignalingConfig = {
    audioURL : string
    videoURL : string
    dataURL  : string
}