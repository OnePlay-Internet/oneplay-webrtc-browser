import { ConnectionEvent, Log, LogConnectionEvent, LogLevel } from "../utils/log";
import { SignalingMessage } from "./msg";
import axios from "axios";
import config from "../../config.json";
import Cookies from "js-cookie";

export class HTTPSignallingClient{
    private url: string;
    private PacketHandler: (Data: SignalingMessage) => Promise<void>;
    private OnOpenHandler: () => Promise<void>;

    private GetOfferIntervalID: NodeJS.Timeout | null = null;
    private GetICEIntervalID: NodeJS.Timeout | null = null;
    private session_id = null;

    private GetSession(){
        if(config.IsDev){
            const data = {
                "session_token": "123",
                "user_id": "123", 
                "session_id": "123"
            }

            return data;
        }

        let session = Cookies.get("op_session_token")
        if(session == null){
            console.log("There is no session");
            return null
        }

        let [user_id, session_token] = atob(session).split(":")
        
        const data = {
            "session_token": session_token,
            "user_id": user_id, 
            "session_id": this.session_id
        }
        return data
    }
    
    constructor(
        url: string,
        OnOpenHandler: () => Promise<void>,
        PacketHandler: (Data: SignalingMessage) => Promise<void>,
        session_id: string
    ) {
        this.url = config.webrtc_service_host+":"+config.webrtc_service_port+config.webrtc_service_prefix;
        this.session_id = session_id;

        this.OnOpenHandler = OnOpenHandler;
        this.PacketHandler = PacketHandler;
    }

    private GetOffer(){        
        const session = this.GetSession()
        if(session != null){
        
        axios.post(this.url+"/webrtc_get_offer", session).then(response => {
            if(response.data.data != null && Object.keys(response.data.data).length != 0){
                Log(LogLevel.Debug, 'Got Offer:'+response.data);
                this.PacketHandler(response.data.data)
                clearInterval(this.GetOfferIntervalID)
            }else{
                Log(LogLevel.Debug, 'No Offer from server');
            }
          })
        }
    }

    private GetICE(){
        const session = this.GetSession()
        if(session != null){

        axios.post(this.url+"/webrtc_get_ice", session).then(response => {
            if(response.data.data != null && Object.keys(response.data.data).length != 0){
                Log(LogLevel.Debug, 'Got ICE:'+response.data);
                this.PacketHandler(response.data.data)
            }else{
                Log(LogLevel.Debug, 'No ICE from server');
            }
          })
        }
    }

    public StopGetICELoop(){
        clearInterval(this.GetICEIntervalID)
    }

    public StartListening(){
        this.OnOpenHandler();
        this.GetOfferIntervalID = setInterval(this.GetOffer.bind(this), 1000);
        this.GetICEIntervalID = setInterval(this.GetICE.bind(this), 1000);
    }

    public StopListening(){
        clearInterval(this.GetOfferIntervalID)
    }

    public SendAnswer(msg: SignalingMessage) {
        let session = this.GetSession()
        session["data"] = msg
        axios.post(this.url+"/webrtc_push_answer", session).then(response => {
        })
    }
}