import { Log, LogLevel } from "../utils/log";
import { EventCode } from "../models/keys.model";
import { HIDMsg, KeyCode, Shortcut, ShortcutCode } from "../models/keys.model";
import { getBrowser, getOS } from "../utils/platform";
import { AxisType } from "../models/hid.model";
import {Screen} from "../models/hid.model"
import { isFullscreen, requestFullscreen } from "../utils/screen";
import { MobileTouch } from "./mobile";
import { DesktopTouch } from "./desktop";
import GamepadManager from "./gamepad";


export class HID {
    private prev_buttons : Map<number,boolean>;
    private prev_sliders : Map<number,number>;
    private prev_axis    : Map<number,number>;

    private buttonMask = 0;

    private shortcuts: Array<Shortcut>

    private relativeMouse : boolean

    private disableKeyboard : boolean
    private disableMouse    : boolean

    private clipboard_buf : string;

    public DisableKeyboard (val: boolean) {
        this.disableKeyboard = val
    }
    public DisableMouse (val: boolean) {
        this.disableMouse = val
    }
    public DisableTouch (val: boolean) {
        this.platform.Toggle(val);
    }

    private Screen : Screen;
    private video: HTMLVideoElement

    private SendFunc: ((data: string) => void)
    private platform : MobileTouch | DesktopTouch

    private GamepadManager: GamepadManager

    constructor(platform : 'mobile' | 'desktop',
                videoElement: HTMLVideoElement, 
                Sendfunc: ((data: string)=>void)){
        this.prev_buttons = new Map<number,boolean>();
        this.prev_sliders = new Map<number,number>();
        this.prev_axis    = new Map<number,number>();

        this.disableKeyboard = false;
        this.disableMouse = false;

        this.video = videoElement;
        this.SendFunc = Sendfunc;
        this.Screen = new Screen();
        this.platform = platform == 'desktop' ? new DesktopTouch(Sendfunc) : new MobileTouch(videoElement,Sendfunc);


        /**
         * video event
         */
        this.video.addEventListener('contextmenu',   ((event: Event) => {event.preventDefault()})); ///disable content menu key on remote control

        /**
         * mouse event
         */
        document.addEventListener('wheel',          this.mouseWheel.bind(this));
        document.addEventListener('mousemove',      this.mouseButtonMovement.bind(this));
        document.addEventListener('mousedown',      this.mouseButtonMovement.bind(this));
        document.addEventListener('mouseup',        this.mouseButtonMovement.bind(this));
        
        window.addEventListener("gamepadconnected", this.gamepadConnected.bind(this));

        /**
         * keyboard event
         */
        document.addEventListener('keydown',        this.keydown.bind(this));
        document.addEventListener('keyup',          this.keyup.bind(this));
        document.addEventListener("fullscreenchange", (event) => {
            if(document.fullscreenEnabled){
                this.video.requestPointerLock();
            }
        });
        /**
         * shortcuts stuff
         */
        this.shortcuts = new Array<Shortcut>();
        this.shortcuts.push(new Shortcut(ShortcutCode.Fullscreen,[KeyCode.Ctrl,KeyCode.Shift,KeyCode.F],
            () => {requestFullscreen(videoElement)}))

        /**
         * mouse pointer stuff
         */
        setInterval(() => {
            const havingPtrLock = document.pointerLockElement != null
            this.relativeMouse = havingPtrLock;

            this.video.style.objectFit = isFullscreen(this.video) || getBrowser() == 'Safari'
                ?  "fill"
                :  "contain"

            if ((isFullscreen(this.video) && !havingPtrLock ) && getBrowser() != 'Safari') {
                this.video.requestPointerLock();
            } else if ((!isFullscreen(this.video) && havingPtrLock) && getBrowser() != 'Safari') {
                document.exitPointerLock();
            }
        }, 5000);
    }



    public SetClipboard(val: string){
        this.clipboard_buf = val;
    }
    public PasteClipboard(){        
        var toks = [
            'cs',
            this.clipboard_buf
          ];

        this.SendFunc(toks.toString());
    }




    public handleIncomingData(data: string) {
        this.platform.handleIncomingData(data);
    }

    public ResetKeyStuck() {
        this.SendFunc((new HIDMsg(EventCode.KeyReset,{ }).ToString()))
    }

    private keydown(event: KeyboardEvent) {
        event.preventDefault();

        let disable_send = false;
        this.shortcuts.forEach((element: Shortcut) => {
            let triggered = element.HandleShortcut(event);

            if (triggered) 
                disable_send = true;
        })



        if (disable_send || this.disableKeyboard) 
            return;


        let jsKey = event.key;
        let code = EventCode.KeyDown

        if(jsKey == "J" || jsKey == "j"){
            this.video.requestPointerLock();
        }

        if(jsKey == "R" || jsKey == "r"){
            this.RestartVideo();
        }

        if(jsKey == "K" || jsKey == "k"){
            this.RequestKeyFrame();
        }

        this.SendFunc((new HIDMsg(code,{
            key: jsKey,
        })).ToString());
    }
    private keyup(event: KeyboardEvent) {
        event.preventDefault();
        if (this.disableKeyboard) 
            return;

        let jsKey = event.key;
        let code = EventCode.KeyUp;
        this.SendFunc((new HIDMsg(code,{
            key: jsKey,
        })).ToString());
    }
    private mouseWheel(event: WheelEvent){        
        let code = EventCode.MouseWheel
        this.SendFunc((new HIDMsg(code,{
            deltaY: -Math.round(event.deltaY),
        })).ToString());
    }
    public mouseMoveRel(event: {movementX: number, movementY: number}){
        console.log("mouseMoveRel: "+event.movementX+"|"+event.movementY);
    }
    private mouseButtonMovement(event: MouseEvent){
            const down = (event.type === "mousedown" ? 1 : 0);
            var mtype = "m";
            var x = event.movementX;
            var y = event.movementY;
          
            if (event.type === "mousedown" || event.type === "mouseup") {
              var mask = 1 << event.button;
              if (down) {
                this.buttonMask |= mask;
              } else {
                this.buttonMask &= ~mask;
              }
            }

            var toks = [
                mtype,
                x,
                y,
                this.buttonMask
              ];

            this.SendFunc(toks.toString());
    }
    private mouseButtonDown(event: MouseEvent){
        if (this.disableMouse) 
            return;

        this.MouseButtonDown(event)
    }
    private mouseButtonUp(event: MouseEvent){
        if (this.disableMouse) 
            return;

        this.MouseButtonUp(event)
    }

    public MouseButtonDown(event: {button: number}){
        let code = EventCode.MouseDown
        this.SendFunc((new HIDMsg(code,{
            button: event.button
        })).ToString());
    }
    public MouseButtonUp(event: {button: number}){
        let code = EventCode.MouseUp
        this.SendFunc((new HIDMsg(code,{
            button: event.button
        })).ToString());
    }



    private clientToServerY(clientY: number): number
    {
        return (clientY - this.Screen.ClientTop) / this.Screen.ClientHeight;
    }

    private clientToServerX(clientX: number): number 
    {
        return (clientX - this.Screen.ClientLeft) / this.Screen.ClientWidth;
    }

    private elementConfig(VideoElement: HTMLVideoElement) 
    {
        this.Screen.ClientWidth  =  VideoElement.offsetWidth;
        this.Screen.ClientHeight =  VideoElement.offsetHeight;
        this.Screen.ClientTop    =  VideoElement.offsetTop;
        this.Screen.ClientLeft   =  VideoElement.offsetLeft;

        this.Screen.StreamWidth  =  VideoElement.videoWidth;
        this.Screen.Streamheight =  VideoElement.videoHeight;

        let desiredRatio = this.Screen.StreamWidth / this.Screen.Streamheight;
        let HTMLVideoElementRatio = this.Screen.ClientWidth / this.Screen.ClientHeight;
        let HTMLdocumentElementRatio = document.documentElement.scrollWidth / document.documentElement.scrollHeight;

        if (HTMLVideoElementRatio > desiredRatio) {
            let virtualWidth = this.Screen.ClientHeight * desiredRatio
            let virtualLeft = ( this.Screen.ClientWidth - virtualWidth ) / 2;

            this.Screen.ClientWidth = virtualWidth
            this.Screen.ClientLeft = virtualLeft
        } else if (HTMLdocumentElementRatio < desiredRatio) {
            let virtualHeight = document.documentElement.offsetWidth / desiredRatio
            let virtualTop    = ( this.Screen.ClientHeight - virtualHeight ) / 2;

            this.Screen.ClientHeight =virtualHeight 
            this.Screen.ClientTop = virtualTop 
        }
    }
    
    private RequestKeyFrame(){
        this.SendFunc("IDR_FRAME");
    }

    private RestartVideo(){
        this.SendFunc("RESTART_VIDEO");
    }

    public VirtualGamepadButtonSlider(isDown: boolean, index: number) {
        this.gamepadButton(0, index, isDown?1:0)
    }

    public VirtualGamepadAxis(x :number, y: number, type: AxisType) {
        const toks = "js|c|"+type[0]+'|'+Math.round(x * 32765)+'|'+Math.round(y * 32765);
        this.SendFunc(toks.toString());
    }


    private gamepadButton(gp_num: number, btn_num: number, val: number): void{
        if (btn_num == 6 || btn_num == 7){
            const toks = "js|b|" + gp_num + "|" + btn_num + "|" + val*255
            this.SendFunc(toks.toString());
          }else{
            const toks = "js|b|" + gp_num + "|" + btn_num + "|" + val
            if(btn_num===3 && val===1) this.RequestKeyFrame();
            if(btn_num===15 && val===1) this.RestartVideo();            
            this.SendFunc(toks.toString());
          }
    }

    private gamepadAxis(gp_num: number, axis_num: number, val: number){
        const toks =
        "js|a|" + gp_num + "|" + axis_num + "|" + Math.round(val * 32765);
        this.SendFunc(toks.toString());
    }

    private gamepadConnected(event: GamepadEvent): void{
        this.GamepadManager = new GamepadManager(
            event.gamepad,
            this.gamepadButton.bind(this),
            this.gamepadAxis.bind(this)
          );
    }
}