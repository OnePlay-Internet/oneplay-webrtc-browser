import IconCircle from './circle.svg';
import DPadTop from './d_pad_top.svg';
import DPadRight from './d_pad_right.svg';
import DPadBottom from './d_pad_bottom.svg';
import DPadLeft from './d_pad_left.svg';
import IconHorizontalPhone from './horizontal.svg';
export { IconCircle, DPadTop, DPadRight, DPadBottom, DPadLeft, IconHorizontalPhone };
